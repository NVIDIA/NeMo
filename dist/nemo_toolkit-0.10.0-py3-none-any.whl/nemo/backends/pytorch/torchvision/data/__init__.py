# Copyright (c) 2019 NVIDIA Corporation
from .image_folder import ImageFolderDataLayer
